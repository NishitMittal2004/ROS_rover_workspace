#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/JoyFeedbackArray.h>
#include <std_msgs/Float32.h>

class JoystickControl
{
    private:
        ros::NodeHandle joy_nh;
        ros::Publisher linear1_pub;
        ros::Publisher linear2_pub;
        ros::Publisher rm_pub;
        ros::Publisher pm_pub;
        ros::Publisher bm_pub;
        ros::Publisher ee_pub;
        ros::Publisher bm_mul_pub;
        ros::Subscriber joy_sub;
        bool enable=true;
        std_msgs::Float32 linear1_msg;
        std_msgs::Float32 linear2_msg;
        std_msgs::Float32 rm_msg;
        std_msgs::Float32 pm_msg;
        std_msgs::Float32 bm_msg;
        std_msgs::Float32 ee_msg;
        std_msgs::Float32 bm_mul_msg;

    public:
        JoystickControl()
        {
            joy_sub = joy_nh.subscribe("/joy", 1, &JoystickControl::joy_callback, this);
            linear1_pub = joy_nh.advertise<std_msgs::Float32>("/arm_linear1", 1);
            linear2_pub = joy_nh.advertise<std_msgs::Float32>("/arm_linear2", 1);
            bm_pub = joy_nh.advertise<std_msgs::Float32>("/arm_base", 1);
            rm_pub = joy_nh.advertise<std_msgs::Float32>("/arm_roll", 1);
            pm_pub = joy_nh.advertise<std_msgs::Float32>("/arm_pitch", 1);
            ee_pub = joy_nh.advertise<std_msgs::Float32>("/arm_end", 1);
            bm_mul_pub= joy_nh.advertise<std_msgs::Float32>("/arm_base_mul", 1);
            
            //this value gets updated only initially
            /*if(!joy_nh.getParam("control_base/enable_button", enable))
            {
                ROS_ERROR("enable value not got");
            }
            */
        }

        void joy_callback(const sensor_msgs::Joy& msg)
        {

            ROS_INFO_STREAM("In callback");
            bool button = msg.buttons[0];
            if(enable && button)
            {
                linear1_msg.data = msg.axes[1];
                linear2_msg.data = msg.axes[5];
                bm_msg.data = msg.axes[2];
                bm_mul_msg.data=msg.buttons[1];
                rm_msg.data = msg.axes[0];
                pm_msg.data = msg.axes[3];
                ee_msg.data = msg.axes[4];
                
            }
            else if(!enable)
            {
                linear1_msg.data = msg.axes[1];
                linear2_msg.data = msg.axes[5];
                bm_msg.data = msg.axes[2];
                bm_mul_msg.data=msg.buttons[1];
                rm_msg.data = msg.axes[0];
                pm_msg.data = msg.axes[3];
                ee_msg.data = msg.axes[4];
            } 
            else
            {
                linear1_msg.data = 0.0;
                linear2_msg.data = 0.0;
                bm_msg.data = 0.0;
                bm_mul_msg.data=0.0;
                rm_msg.data = 0.0;
                pm_msg.data = 0.0;
                ee_msg.data = 0.0;
            }

            ROS_INFO("Linear1 = %f, Linear2 = %f, Pitch = %f, Base = %f, Roll = %f, End effector = %f, Base_mul=%f", linear1_msg.data,linear2_msg.data,pm_msg.data,bm_msg.data,rm_msg.data,ee_msg.data,bm_mul_msg.data);
            linear1_pub.publish(linear1_msg);
            linear2_pub.publish(linear2_msg);
            bm_pub.publish(bm_msg);
            bm_mul_pub.publish(bm_mul_msg);
            pm_pub.publish(pm_msg);
            rm_pub.publish(rm_msg);
            ee_pub.publish(ee_msg);


        }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "control_base");
    JoystickControl jc;
    ros::spin();
    return 0;
}