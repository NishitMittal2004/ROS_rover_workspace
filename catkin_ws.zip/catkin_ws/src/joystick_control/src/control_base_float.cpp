#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/JoyFeedbackArray.h>
#include <std_msgs/Float32.h>

class JoystickControl
{
    private:
        ros::NodeHandle joy_nh;
        ros::Publisher linear_pub;
        ros::Publisher angular_pub;
        ros::Subscriber joy_sub;
        // ros::Publisher stop_pub;
        bool enable=true;
	    std_msgs::Float32 linear_msg;
        std_msgs::Float32 angular_msg;

    public:
        JoystickControl()
        {
            joy_sub = joy_nh.subscribe("/joy", 1, &JoystickControl::joy_callback, this);
            linear_pub = joy_nh.advertise<std_msgs::Float32>("/base_linear", 10);
            angular_pub = joy_nh.advertise<std_msgs::Float32>("/base_angular", 1);
            // stop_pub = joy_nh.advertise<std_msgs::Float32>("/stop", 1);
            
            //this value gets updated only initially
            /*if(!joy_nh.getParam("control_base/enable_button", enable))
            {
                ROS_ERROR("enable value not got");
            }
            */
        }

        void joy_callback(const sensor_msgs::Joy& msg)
        {

            ROS_INFO_STREAM("In callback");
            bool button = msg.buttons[0];
            // bool stop = msg.buttons[11];

            
            if(enable && button)
            {
                linear_msg.data = msg.axes[1];
                angular_msg.data = msg.axes[2];
            }
            else if(!enable)
            {
                linear_msg.data = msg.axes[1];
                angular_msg.data = msg.axes[2];
            } 
            else
            {
                linear_msg.data = -0.0;
                angular_msg.data = -0.0;
            }

        
            

            ROS_INFO("Linear = %f, Angular = %f", linear_msg.data, angular_msg.data);
            linear_pub.publish(linear_msg);
            angular_pub.publish(angular_msg);

            

            

        }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "control_base");
    JoystickControl jc;
    ros::spin();
    return 0;
}