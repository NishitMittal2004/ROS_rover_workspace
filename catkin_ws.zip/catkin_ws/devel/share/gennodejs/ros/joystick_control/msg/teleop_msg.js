// Auto-generated. Do not edit!

// (in-package joystick_control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class teleop_msg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.lin = null;
      this.ang = null;
    }
    else {
      if (initObj.hasOwnProperty('lin')) {
        this.lin = initObj.lin
      }
      else {
        this.lin = 0.0;
      }
      if (initObj.hasOwnProperty('ang')) {
        this.ang = initObj.ang
      }
      else {
        this.ang = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type teleop_msg
    // Serialize message field [lin]
    bufferOffset = _serializer.float32(obj.lin, buffer, bufferOffset);
    // Serialize message field [ang]
    bufferOffset = _serializer.float32(obj.ang, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type teleop_msg
    let len;
    let data = new teleop_msg(null);
    // Deserialize message field [lin]
    data.lin = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ang]
    data.ang = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'joystick_control/teleop_msg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2bdf9614b085adfa4e48147b4424cc98';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 lin
    float32 ang
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new teleop_msg(null);
    if (msg.lin !== undefined) {
      resolved.lin = msg.lin;
    }
    else {
      resolved.lin = 0.0
    }

    if (msg.ang !== undefined) {
      resolved.ang = msg.ang;
    }
    else {
      resolved.ang = 0.0
    }

    return resolved;
    }
};

module.exports = teleop_msg;
